import React from "react";

const Navbar = () => {
  return (
    <nav>
      <h1>Expense Manager</h1>
    </nav>
  );
};

export default Navbar;
